<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CTF Challenge</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            width: 80%;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #4CAF50;
        }
        .form-container {
            text-align: center;
            margin-bottom: 20px;
        }
        input[type="text"] {
            padding: 10px;
            width: 60%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            border: none;
            background-color: #4CAF50;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .result {
            background-color: #e9f7e9;
            padding: 15px;
            border: 1px solid #d4e8d4;
            border-radius: 4px;
            margin-top: 20px;
        }
        footer {
            text-align: center;
            margin-top: 40px;
            font-size: 14px;
            color: #777;
        }
        footer a {
            color: #4CAF50;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Enter IP Address to run Ping Command</h1>
        <div class="form-container">
            <form method="GET" action="">
                <input type="text" name="ip" placeholder="Enter IP address" required>
                <input type="submit" value="Run">
            </form>
        </div>
    </div>
<!-- People usualy hide some info in text files -->
</body>
</html>
<?php
if (isset($_REQUEST['ip'])) {
    $target = $_REQUEST['ip'];

    if (strpos($target, 'cat flag.txt') !== false) {
        include('image.php');
        exit;
    }
    $cmd = shell_exec('ping -n 4 ' . $target);
    echo "<pre>{$cmd}</pre>";
}
?>