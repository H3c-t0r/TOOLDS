<img src="image.jpg" alt="Image">
